package com.example.redlinefps;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.g3d.utils.ModelBatch;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class RedlineGame extends ApplicationAdapter {
    private PerspectiveCamera camera;
    private ModelBatch modelBatch;
    private Environment environment;
    private ModelBuilder builder;
    private final Array<ModelInstance> world = new Array<>();
    private final Array<Model> models = new Array<>();
    private final Array<Enemy> enemies = new Array<>();
    private SpriteBatch uiBatch;
    private BitmapFont font;
    private ShapeRenderer shapes;
    private float yaw = 0f, pitch = 0f;
    private float playerX = 0f, playerZ = 7f;
    private float moveX = 0f, moveY = 0f;
    private int health = 100, ammo = 30, score = 0;
    private float fireCooldown = 0f;
    private float joyPointerX, joyPointerY;
    private boolean joystickActive = false;
    private int joystickPointer = -1;
    private int lookPointer = -1;
    private float lastLookX, lastLookY;
    private boolean fireHeld = false;
    private final Vector3 tmp = new Vector3();
    private long lastShotTime = 0;

    private static class Enemy {
        ModelInstance instance;
        float x, z;
        float hp = 1f;
        Enemy(ModelInstance instance, float x, float z) {
            this.instance = instance; this.x = x; this.z = z;
        }
    }

    @Override public void create() {
        modelBatch = new ModelBatch();
        builder = new ModelBuilder();
        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.68f, 0.68f, 0.72f, 1f));
        environment.add(new DirectionalLight().set(0.85f, 0.82f, 0.75f, -0.4f, -1f, -0.25f));
        camera = new PerspectiveCamera(70, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.near = 0.1f; camera.far = 100f;
        camera.position.set(playerX, 1.7f, playerZ);
        updateCameraDirection();
        camera.update();

        addBox(0, -0.25f, 0, 40, 0.5f, 40, new Color(0.25f,0.28f,0.27f,1)); // ground
        // Concrete perimeter and tactical cover
        addBox(0, 1.5f, -18, 40, 3, 1, new Color(0.34f,0.36f,0.37f,1));
        addBox(-18, 1.5f, 0, 1, 3, 36, new Color(0.31f,0.33f,0.34f,1));
        addBox(18, 1.5f, 0, 1, 3, 36, new Color(0.31f,0.33f,0.34f,1));
        addBox(-4, 0.8f, 1, 3, 1.6f, 2, new Color(0.43f,0.40f,0.34f,1));
        addBox(4, 0.8f, -3, 3, 1.6f, 2, new Color(0.43f,0.40f,0.34f,1));
        addBox(0, 0.6f, -8, 5, 1.2f, 1.5f, new Color(0.37f,0.39f,0.4f,1));
        addBox(-9, 0.65f, -6, 2.4f, 1.3f, 2.4f, new Color(0.4f,0.35f,0.28f,1));
        addBox(10, 0.65f, 4, 2.4f, 1.3f, 2.4f, new Color(0.4f,0.35f,0.28f,1));
        spawnEnemy(-7, -9); spawnEnemy(7, -11); spawnEnemy(10, -2);
        spawnEnemy(-11, 3); spawnEnemy(1, -14);
        uiBatch = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(1.25f);
        shapes = new ShapeRenderer();
    }

    private void addBox(float x,float y,float z,float w,float h,float d,Color c) {
        Model m = builder.createBox(w,h,d,
            new Material(ColorAttribute.createDiffuse(c)),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        models.add(m);
        ModelInstance i = new ModelInstance(m);
        i.transform.setToTranslation(x,y,z);
        world.add(i);
    }
    private void spawnEnemy(float x,float z) {
        Model m = builder.createCapsule(0.42f, 1.7f, 12,
            new Material(ColorAttribute.createDiffuse(new Color(0.72f,0.12f,0.10f,1))),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        models.add(m);
        ModelInstance i = new ModelInstance(m);
        i.transform.setToTranslation(x,0.85f,z);
        enemies.add(new Enemy(i,x,z));
    }
    private void updateCameraDirection() {
        float cp = MathUtils.cos(pitch);
        camera.direction.set(-MathUtils.sin(yaw)*cp, MathUtils.sin(pitch), -MathUtils.cos(yaw)*cp).nor();
        camera.up.set(Vector3.Y);
    }

    @Override public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 0.05f);
        fireCooldown -= dt;
        handleInput(dt);
        updateEnemies(dt);
        camera.position.set(playerX, 1.7f, playerZ);
        updateCameraDirection(); camera.update();

        ScreenUtils.clear(0.48f,0.57f,0.62f,1f, true);
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);
        modelBatch.begin(camera);
        for (ModelInstance i : world) modelBatch.render(i, environment);
        for (Enemy e : enemies) modelBatch.render(e.instance, environment);
        modelBatch.end();
        drawUi();
    }

    private void handleInput(float dt) {
        // Desktop fallback controls for emulator
        if (Gdx.input.isKeyPressed(Input.Keys.W)) moveY = 1;
        else if (Gdx.input.isKeyPressed(Input.Keys.S)) moveY = -1;
        if (Gdx.input.isKeyPressed(Input.Keys.A)) moveX = -1;
        else if (Gdx.input.isKeyPressed(Input.Keys.D)) moveX = 1;
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) yaw += 1.8f*dt;
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) yaw -= 1.8f*dt;
        if (Gdx.input.isKeyPressed(Input.Keys.UP)) pitch = MathUtils.clamp(pitch+1.3f*dt,-0.85f,0.85f);
        if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) pitch = MathUtils.clamp(pitch-1.3f*dt,-0.85f,0.85f);
        if (Gdx.input.isKeyPressed(Input.Keys.SPACE)) shoot();

        float speed = 5f;
        float fx = -MathUtils.sin(yaw), fz = -MathUtils.cos(yaw);
        float rx = MathUtils.cos(yaw), rz = -MathUtils.sin(yaw);
        playerX += (fx*moveY + rx*moveX)*speed*dt;
        playerZ += (fz*moveY + rz*moveX)*speed*dt;
        playerX = MathUtils.clamp(playerX,-16.5f,16.5f);
        playerZ = MathUtils.clamp(playerZ,-16.5f,16.5f);
        moveX = 0; moveY = 0;

        if (Gdx.input.justTouched()) {
            float x = Gdx.input.getX();
            float y = Gdx.graphics.getHeight()-Gdx.input.getY();
            if (x < Gdx.graphics.getWidth()*0.42f && y < Gdx.graphics.getHeight()*0.72f) {
                joystickActive = true; joystickPointer = 0; joyPointerX=x; joyPointerY=y;
            } else if (x > Gdx.graphics.getWidth()*0.76f && y < Gdx.graphics.getHeight()*0.34f) {
                shoot();
            } else {
                lookPointer = 0; lastLookX=x; lastLookY=y;
            }
        }
        if (Gdx.input.isTouched()) {
            float x=Gdx.input.getX(), y=Gdx.graphics.getHeight()-Gdx.input.getY();
            if (joystickActive && joystickPointer==0) {
                float dx=x-joyPointerX, dy=y-joyPointerY;
                moveX=MathUtils.clamp(dx/70f,-1,1);
                moveY=MathUtils.clamp(-dy/70f,-1,1);
            } else if (lookPointer==0) {
                float dx=x-lastLookX, dy=y-lastLookY;
                yaw -= dx*0.006f;
                pitch = MathUtils.clamp(pitch-dy*0.005f,-0.85f,0.85f);
                lastLookX=x; lastLookY=y;
            }
        } else {
            joystickActive=false; joystickPointer=-1; lookPointer=-1;
        }
    }

    private void updateEnemies(float dt) {
        for (Enemy e : enemies) {
            float dx=playerX-e.x, dz=playerZ-e.z;
            float dist=(float)Math.sqrt(dx*dx+dz*dz);
            if (dist > 1.8f && dist < 24f) {
                e.x += dx/dist*0.7f*dt;
                e.z += dz/dist*0.7f*dt;
                e.instance.transform.setToTranslation(e.x,0.85f,e.z);
            } else if (dist <= 1.8f && health > 0) {
                health = Math.max(0, health-(int)(8*dt));
            }
        }
    }

    private void shoot() {
        if (fireCooldown > 0 || ammo <= 0 || health <= 0) return;
        fireCooldown = 0.22f; ammo--;
        Enemy hit = null;
        float best = 100f;
        Vector3 origin = camera.position;
        Vector3 dir = new Vector3(camera.direction).nor();
        for (Enemy e : enemies) {
            Vector3 target = new Vector3(e.x,0.85f,e.z);
            Vector3 to = target.cpy().sub(origin);
            float along = to.dot(dir);
            if (along > 0 && along < best) {
                Vector3 closest = origin.cpy().mulAdd(dir,along);
                if (closest.dst(target) < 0.85f) { best=along; hit=e; }
            }
        }
        if (hit != null) {
            enemies.removeValue(hit,true);
            score += 100;
            // respawn after a short delay is intentionally omitted in this prototype
        }
    }

    private void drawUi() {
        float w=Gdx.graphics.getWidth(), h=Gdx.graphics.getHeight();
        shapes.setProjectionMatrix(uiBatch.getProjectionMatrix());
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        // HUD panel
        shapes.setColor(0,0,0,0.48f); shapes.rect(12,h-54,250,42);
        // joystick visual
        shapes.setColor(1,1,1,0.16f); shapes.circle(95,88,54);
        shapes.setColor(1,1,1,0.42f); shapes.circle(95+moveX*24,88-moveY*24,21);
        // fire button
        shapes.setColor(0.72f,0.08f,0.06f,0.78f); shapes.circle(w-88,88,54);
        shapes.setColor(1,1,1,0.22f); shapes.circle(w-88,88,44);
        shapes.end();
        uiBatch.begin();
        font.setColor(Color.WHITE);
        font.draw(uiBatch,"REDLINE FPS",22,h-22);
        font.draw(uiBatch,"HP "+health+"     AMMO "+ammo+"     SCORE "+score,22,h-43);
        font.draw(uiBatch,"MOVE",62,25);
        font.draw(uiBatch,"FIRE",w-111,25);
        font.draw(uiBatch,"Swipe right side to aim",w/2-90,28);
        if (health<=0) font.draw(uiBatch,"YOU ARE DOWN — close and restart",w/2-155,h/2);
        uiBatch.end();
        // crosshair
        shapes.begin(ShapeRenderer.ShapeType.Line);
        shapes.setColor(Color.WHITE);
        shapes.line(w/2-9,h/2,w/2-3,h/2); shapes.line(w/2+3,h/2,w/2+9,h/2);
        shapes.line(w/2,h/2-9,w/2,h/2-3); shapes.line(w/2,h/2+3,w/2,h/2+9);
        shapes.end();
    }

    @Override public void dispose() {
        modelBatch.dispose(); uiBatch.dispose(); font.dispose(); shapes.dispose();
        for (Model m : models) m.dispose();
    }
}
