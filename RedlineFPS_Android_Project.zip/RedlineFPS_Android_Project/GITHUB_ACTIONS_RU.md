# Сборка APK через GitHub Actions (с телефона тоже можно)

1. Создай новый репозиторий GitHub.
2. Загрузи в него содержимое этой папки, сохраняя структуру каталогов.
3. В репозитории открой **Add file → Create new file**.
4. В поле имени укажи `.github/workflows/android.yml` (GitHub создаст папки автоматически).
5. Вставь workflow ниже и нажми Commit changes.
6. Открой вкладку **Actions**, выбери workflow и дождись зелёного статуса.
7. Открой завершённый запуск → **Artifacts** → скачай `redline-fps-debug-apk.zip`, распакуй его и установи APK.

```yaml
name: Build Android APK
on:
  workflow_dispatch:
  push:
    branches: [ "main" ]
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - uses: gradle/actions/setup-gradle@v4
      - name: Build debug APK
        run: gradle --no-daemon assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: redline-fps-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

Примечание: GitHub Actions может потребовать корректировку версии Android Gradle Plugin или Gradle wrapper в зависимости от образа сборки. Если workflow упадёт, открой лог ошибки и используй его для исправления.
